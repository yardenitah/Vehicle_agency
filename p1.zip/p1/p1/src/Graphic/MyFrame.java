package Graphic;
import Vehicless.*;
import Vehicless.Vehicles;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Vector;

public class MyFrame extends JFrame implements ActionListener {
    private static int numOfVehicle;
    private Box boxContainer;
    private JFrame frame;
    private JPanel panel, innerPanel;
    private boolean withTheWind, againstTheWind, civilian, military;
    private JTextField modelText, submodelText, LicenseText, maxKmText, maxOfPassengerText, maxSpeedText, lifeTimeText, numOfWheelsText, countryFlagText, averageLifeSpanText, avgConsumptionText, kmText;
    private JRadioButton withTheWindButton, againstTheWindButton, civilianButton, militaryButton, radioFlagBtn;
    private ButtonGroup buttonGroup, buttonVehiclesGroup;
    private JLabel waterTypeLabel, typeLabel, modelLabel, SubmodelLabel, LicenseLabel, maxKmLabel, maxOfPassengerLabel, maxSpeedLabel, lifeTimeLabel, numOfWheelsLabel, countryFlagLabel, avgConsumptionLabel, averageLifeSpanLabel, kmLabel;
    private JComboBox<String> vehicleListBox, waterVehicleBox, airVehicleBox, landVehicleBox;
    private static JButton menuButton, buyVehicles, testDrive, resetkm, changeFlagsn, addVehicle, addVehicleBtn, resetFlagBtn, currentInventoryReportBtn;
    private final ArrayList<Vehicles> arr;
    ImageIcon vehiclesImage;
//    private Vehicles vehicleSelected;

    private static enum VehicleType {
        Jeep, Frigate, Bicycle, CruiseShip, PlayGlider, SpyGlider, Amphibious, HybridPlane, ElectricBicycle
    }
    private static enum Country {
        Greece, Israel, Somalia, Italy, UnitedStates, Germany, Pirates
    }

    private Image placeHolderImage;
    private boolean imageSelcted;
    private final int width = 800, height = 600;

    public MyFrame() {
        this.arr = new ArrayList<>();
        vehiclesImage = new ImageIcon();
        imageSelcted = false;
        buttonGroup = new ButtonGroup();
        frame = new JFrame();
        panel = new JPanel();
        innerPanel = new JPanel();
        panel.setLayout(null);
        innerPanel.setBackground(new Color(0, 0, 0, 224));
        innerPanel.setLayout(new BorderLayout());
        innerPanel.setSize(width / 2, height / 2);
        frame.setTitle("My vehicleAgency");
        frame.setSize(width, height);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(panel);
        frame.setResizable(false);
        panel.setLayout(null);
        frame.setLocationRelativeTo(null);  // Center the frame on the screen
        panel.setBackground(new Color(0, 0, 0, 224));

        addvehicleBox();
    }

    public void showOrHide(boolean x) {
        frame.setVisible(x);
    }

    private void resetPanel() {
        if (panel != null) {
            panel.removeAll();
            panel.revalidate();
            panel.repaint();
        }
    }

    private void resetInnerPanel() {
        if (innerPanel != null) {
            innerPanel.removeAll();
            innerPanel.revalidate();
            innerPanel.repaint();
        }
    }

    private void resetAllTextFields() {
        if (this.boxContainer != null)
            boxContainer.removeAll();
    }

    private void addvehicleBox() {
        resetAllTextFields();
        resetInnerPanel();
        resetPanel();
        typeLabel = new JLabel("Please select vehicle type :");
        typeLabel.setForeground(new Color(255, 255, 255, 255));
        typeLabel.setBounds(45, 20, 180, 100);
        panel.add(typeLabel);

        vehicleListBox = new JComboBox<>(new Vector<>(List.of("Land Vehicle", "Water Vehicle", "Air Vehicle")));
        vehicleListBox.setBounds(235, 50, 150, 45);
        vehicleListBox.setBackground(new Color(255, 255, 255, 255));
        vehicleListBox.setForeground(Color.blue);
        vehicleListBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addVehicle();
            }
        });
        panel.add(vehicleListBox);
        goToMenuButton();
    }

    private void addVehicle() {

        int option = vehicleListBox.getSelectedIndex();

        switch (option) {
            case 0 -> {
                vehicleListBox.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        addLandVehicleBox();
                    }
                });
                System.out.println("Land vehicle successfully added");
            }
            case 1 -> {
                vehicleListBox.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        addWaterVehicleBox();
                    }
                });
                System.out.println("Water vehicle successfully added");
            }
            case 2 -> {
                vehicleListBox.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        addAirVehicleBox();
                    }
                });
                System.out.println("Air vehicle successfully added");
            }
        }
    }

    private void addWaterVehicleBox() {
        resetPanel();
        waterTypeLabel = new JLabel("What type of water vehicle :");
        waterTypeLabel.setForeground(new Color(255, 255, 255, 255));
        waterTypeLabel.setBounds(45, 20, 180, 100);
        panel.add(waterTypeLabel);

        waterVehicleBox = new JComboBox<>(new Vector<>(List.of(" Frigate", "Cruise ship", "amphibious", "Hybrid plain")));
        waterVehicleBox.setBounds(235, 50, 150, 45);
        waterVehicleBox.setBackground(new Color(255, 255, 255, 255));
        waterVehicleBox.setForeground(Color.blue);
        waterVehicleBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addWaterVehicle();
            }
        });
        panel.add(waterVehicleBox);
        goToMenuButton();
    }

    private void addAirVehicleBox() {
        resetPanel();
        waterTypeLabel = new JLabel("What type of air vehicle :");
        waterTypeLabel.setForeground(new Color(255, 255, 255, 255));
        waterTypeLabel.setBounds(45, 20, 180, 100);
        panel.add(waterTypeLabel);

        airVehicleBox = new JComboBox<>(new Vector<>(List.of("Play glider", "Spay glider", "Hybrid plane")));
        airVehicleBox.setBounds(228, 50, 150, 45);
        airVehicleBox.setBackground(new Color(255, 255, 255, 255));
        airVehicleBox.setForeground(Color.blue);
        airVehicleBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addAirVehicle();
            }
        });
        panel.add(airVehicleBox);
        goToMenuButton();
    }

    private void addLandVehicleBox() {
        resetAllTextFields();
        resetInnerPanel();
        resetPanel();
        waterTypeLabel = new JLabel("What type of land vehicle :");
        waterTypeLabel.setForeground(new Color(255, 255, 255, 255));
        waterTypeLabel.setBounds(45, 20, 180, 100);
        panel.add(waterTypeLabel);

        landVehicleBox = new JComboBox<>(new Vector<>(List.of("Jeep", "Bicycle", "amphibious", "Hybrid Plain", "Electric bicycle")));
        landVehicleBox.setBounds(228, 50, 150, 45);
        landVehicleBox.setBackground(new Color(255, 255, 255, 255));
        landVehicleBox.setForeground(Color.blue);
        landVehicleBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addLandVehicle();
            }
        });
        panel.add(landVehicleBox);
        goToMenuButton();
    }

    private void addHybridPlain() {
        JLabel tmpLabel = new JLabel();
        tmpLabel.setText("enter Hybrid Plain data :");
        boxContainer.add(tmpLabel);
        boxContainer.add(civilianOrMilitaryRadioButtons());
        boxContainer.add(modelLabel());
        boxContainer.add(subMudelLabel());
        boxContainer.add(maxKmLabel());
        boxContainer.add(maxPassengersLabel());
        boxContainer.add(msxSpeedLabel());
        boxContainer.add(avgConsumptionLabel());
        boxContainer.add(averageLifeSpanLabel());
        boxContainer.add(numOfWheelsLabel());
        boxContainer.add(windRadioButtons());
        boxContainer.add(addPicture());
        boxContainer.add(addVehicleBtn(VehicleType.HybridPlane)); // creat this object
        innerPanel.add(boxContainer, BorderLayout.CENTER);
        innerPanel.setBounds(220, 50, width / 2, (height / 2) + 190);
        panel.add(innerPanel);
    }

    private void addAmphibious() {
        JLabel tmpLabel = new JLabel();
        tmpLabel.setText("enter amphibious data :");
        boxContainer.add(tmpLabel);
        boxContainer.add(modelLabel());
        boxContainer.add(subMudelLabel());
        boxContainer.add(maxKmLabel());
        boxContainer.add(maxPassengersLabel());
        boxContainer.add(msxSpeedLabel());
        boxContainer.add(avgConsumptionLabel());
        boxContainer.add(numOfWheelsLabel());
        boxContainer.add(windRadioButtons());
        boxContainer.add(addPicture());
        boxContainer.add(addVehicleBtn(VehicleType.Amphibious)); // creat this object
        innerPanel.add(boxContainer, BorderLayout.CENTER);
        innerPanel.setBounds(220, 50, width /2, (height+90) / 2);
        panel.add(innerPanel);
    }

    private void addLandVehicle() {
        resetPanel();
        boxContainer = Box.createVerticalBox();
        boxContainer.setSize(width, height);
        goToMenuButton();
        JLabel tmpLabel = new JLabel();
        tmpLabel.setForeground(Color.WHITE);
        tmpLabel.setBackground(Color.cyan);
        tmpLabel.setFont(new Font(Font.SERIF, Font.PLAIN, 20));

        int option = landVehicleBox.getSelectedIndex();
        switch (option) {
            case 0 -> { // Jeep
                tmpLabel.setText("enter Jeep data :");
                boxContainer.add(tmpLabel);
                boxContainer.add(modelLabel());
                boxContainer.add(subMudelLabel());
                boxContainer.add(maxKmLabel());
                boxContainer.add(maxPassengersLabel());
                boxContainer.add(msxSpeedLabel());
                boxContainer.add(avgConsumptionLabel());
                boxContainer.add(averageLifeSpanLabel());
                boxContainer.add(addPicture());
                boxContainer.add(addVehicleBtn(VehicleType.Jeep)); // creat this object
                innerPanel.add(boxContainer, BorderLayout.CENTER);
                innerPanel.setBounds(220, 50, width / 2, height / 2);
                panel.add(innerPanel);
            }
            case 1 -> { //Bicycle
                tmpLabel.setText("enter Bicycle data :");
                boxContainer.add(tmpLabel);
                boxContainer.add(modelLabel());
                boxContainer.add(subMudelLabel());
                boxContainer.add(addPicture());
                boxContainer.add(addVehicleBtn(VehicleType.Bicycle)); // creat this object
                innerPanel.add(boxContainer, BorderLayout.CENTER);
                innerPanel.setBounds(220, 50, width / 2, height / 3);
                panel.add(innerPanel);
            }
            case 2->{  // amphibious
                addAmphibious();
            }
            case 3->{  // HybridPlain
                addHybridPlain();
            }
            case 4-> { // ElectricBicycle
                tmpLabel.setText("enter Electric bicycle data :");
                boxContainer.add(tmpLabel);
                boxContainer.add(modelLabel());
                boxContainer.add(subMudelLabel());
                boxContainer.add(addPicture());
                boxContainer.add(addVehicleBtn(VehicleType.ElectricBicycle)); // creat this object
                innerPanel.add(boxContainer, BorderLayout.CENTER);
                innerPanel.setBounds(220, 50, width / 2, height / 3);
                panel.add(innerPanel);
            }
        }
    }

    public void addAirVehicle() {
        resetPanel();
        boxContainer = Box.createVerticalBox();
        boxContainer.setSize(width, height);
        goToMenuButton();
        JLabel tmpLabel = new JLabel();
        tmpLabel.setForeground(Color.WHITE);
        tmpLabel.setBackground(Color.cyan);
        tmpLabel.setFont(new Font(Font.SERIF, Font.PLAIN, 20));
        int option = airVehicleBox.getSelectedIndex();

        switch (option) {
            case 0 -> { // Play glider
                tmpLabel.setText("enter Play glider data :");
                boxContainer.add(tmpLabel);
                boxContainer.add(maxKmLabel());
                boxContainer.add(averageLifeSpanLabel());
                boxContainer.add(addPicture());
                boxContainer.add(addVehicleBtn(VehicleType.PlayGlider)); // creat this object
                innerPanel.add(boxContainer, BorderLayout.CENTER);
                innerPanel.setBounds(220, 50, width / 2, height / 2);
                panel.add(innerPanel);
            }
            case 1 -> { // Spay glider
                tmpLabel.setText("enter Spay glider data :");
                boxContainer.add(tmpLabel);
                boxContainer.add(maxKmLabel());
                boxContainer.add(averageLifeSpanLabel());
                boxContainer.add(addPicture());
                boxContainer.add(addVehicleBtn(VehicleType.SpyGlider)); // creat this object
                innerPanel.add(boxContainer, BorderLayout.CENTER);
                innerPanel.setBounds(220, 50, width / 2, height / 2);
                panel.add(innerPanel);
            }
            case 2-> { // hybridPlain
                addHybridPlain();
            }
        }


    }

    public void addWaterVehicle() {
        resetPanel();
        boxContainer = Box.createVerticalBox(); // Makes all the boxes be in the middle
        boxContainer.setSize(width, height);
        goToMenuButton();
        JLabel tmpLabel = new JLabel();
        tmpLabel.setForeground(Color.WHITE);
        tmpLabel.setBackground(Color.cyan);
        tmpLabel.setFont(new Font(Font.SERIF, Font.PLAIN, 20));
        int option = waterVehicleBox.getSelectedIndex();

        switch (option) {
            case 0 -> { // Frigate
                tmpLabel.setText("enter Frigate data :");
                boxContainer.add(tmpLabel);
                boxContainer.add(modelLabel());
                boxContainer.add(maxKmLabel());
                boxContainer.add(maxPassengersLabel());
                boxContainer.add(msxSpeedLabel());
                boxContainer.add(windRadioButtons());
                boxContainer.add(addPicture());
                boxContainer.add(addVehicleBtn(VehicleType.Frigate)); // creat this object
                innerPanel.add(boxContainer, BorderLayout.CENTER);
                innerPanel.setBounds(220, 50, width / 2, height / 2);
                panel.add(innerPanel);
            }
            case 1 -> { // Cruise ship
                tmpLabel.setText("enter Cruise ship data :");
                boxContainer.add(modelLabel());
                boxContainer.add(maxKmLabel());
                boxContainer.add(maxPassengersLabel());
                boxContainer.add(msxSpeedLabel());
                boxContainer.add(averageLifeSpanLabel());
                boxContainer.add(countryFlagLabel());
                boxContainer.add(addPicture());
                boxContainer.add(addVehicleBtn(VehicleType.CruiseShip)); // creat this object
                innerPanel.add(boxContainer, BorderLayout.CENTER);
                innerPanel.setBounds(220, 50, width / 2, height / 2);
                panel.add(innerPanel);
            }
            case 2 -> { // amphibious
                addAmphibious();
            }
            case 3-> { // HybridPlain
                addHybridPlain();
            }
        }
    }

    public Box addPicture() { // to add cars image when user add car
        Box box = Box.createHorizontalBox();
        try {
            BufferedImage bufferedImage = ImageIO.read(new File("/Users/yrdnqldrwn/Desktop/SOFTWARE/IntelliJ #Java/homeWork/p1/p1/src/Graphic/placeHolder.png"));
            placeHolderImage = bufferedImage;
            bufferedImage = resizePic(bufferedImage, 100, 70);
            vehiclesImage.setImage(bufferedImage);
            JLabel label = new JLabel(vehiclesImage);
            box.add(label);
            JButton addPicBtn = new JButton("Add Picture ");
            addPicBtn.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    JFileChooser fileChooser = new JFileChooser();
                    fileChooser.addChoosableFileFilter(new ImageFilter());
                    fileChooser.setAcceptAllFileFilterUsed(false);
                    int option = fileChooser.showOpenDialog(frame);
                    if (option == JFileChooser.APPROVE_OPTION) {
                        File file = fileChooser.getSelectedFile();
                        try {
                            BufferedImage bufferedImage = ImageIO.read(file);
                            bufferedImage = resizePic(bufferedImage, 100, 70);
                            vehiclesImage.setImage(bufferedImage);
                            imageSelcted = true;
                        } catch (Exception x) {
                            x.printStackTrace();
                        }
                        label.setText("File Selected: " + file.getName());
                    } else {
                        label.setText("Open command canceled");
                    }
                }
            });
            box.add(addPicBtn);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return box;
    }

    private Box modelLabel() {
        Box box = Box.createHorizontalBox();
        modelLabel = new JLabel("Model :");
        modelLabel.setForeground(Color.WHITE);
        modelLabel.setBackground(Color.cyan);
        box.add(modelLabel);

        modelText = new JTextField();
        box.add(modelText);
        box.setSize(150, 10);
        return box;
    }
    private Box numOfWheelsLabel() {
        Box box = Box.createHorizontalBox();
        numOfWheelsLabel = new JLabel("number of wheels :");
        numOfWheelsLabel.setForeground(Color.WHITE);
        numOfWheelsLabel.setBackground(Color.cyan);
        box.add(numOfWheelsLabel);

        numOfWheelsText = new JTextField();
        numOfWheelsText.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                int key = e.getKeyCode();
                if (e.getKeyChar() >= '0' && e.getKeyChar() <= '9') {
                    numOfWheelsText.setEditable(true);
                } else numOfWheelsText.setEditable(false);
            }
        });
        box.add(numOfWheelsText);
        box.setSize(150, 10);
        return box;
    }
    private Box maxKmLabel() {
        Box box = Box.createHorizontalBox();
        maxKmLabel = new JLabel("max Km :");
        maxKmLabel.setForeground(Color.WHITE);
        maxKmLabel.setBackground(Color.cyan);
        box.add(maxKmLabel);

        maxKmText = new JTextField();
        maxKmText.setBackground(new Color(255, 255, 255, 255));
        maxKmText.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                int key = e.getKeyCode();
                if (e.getKeyChar() >= '0' && e.getKeyChar() <= '9') {
                    maxKmText.setEditable(true);
                } else maxKmText.setEditable(false);
            }
        });
        box.add(maxKmText);
        box.setSize(150, 10);
        return box;
    }

    private Box kmLabel() {
        Box box = Box.createHorizontalBox();
        kmLabel = new JLabel("Enter the number of kilometers traveled :");
        kmLabel.setForeground(Color.WHITE);
        kmLabel.setBackground(Color.cyan);
        box.add(kmLabel);

        kmText = new JTextField();
        kmText.setBackground(Color.WHITE);
        kmText.setPreferredSize(new Dimension(180, kmText.getPreferredSize().height));
        kmText.setPreferredSize(new Dimension(kmText.getPreferredSize().width, 20));
        kmText.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                int key = e.getKeyCode();
                if (e.getKeyChar() >= '0' && e.getKeyChar() <= '9' || e.getKeyChar() == KeyEvent.VK_DELETE) {
                    kmText.setEditable(true);
                } else kmText.setEditable(false);
            }
        });
        box.add(kmText);
        return box;
    }

    private Box subMudelLabel() {
        Box box = Box.createHorizontalBox();
        SubmodelLabel = new JLabel("Sub model :");
        SubmodelLabel.setForeground(Color.WHITE);
        SubmodelLabel.setBackground(Color.cyan);
        box.add(SubmodelLabel);

        submodelText = new JTextField();
        submodelText.setBackground(new Color(255, 255, 255, 255));
        box.add(submodelText);
        box.setSize(150, 10);
        return box;
    }

    private Box msxSpeedLabel() {
        Box box = Box.createHorizontalBox();
        modelLabel = new JLabel("max speed :");
        modelLabel.setForeground(Color.WHITE);
        modelLabel.setBackground(Color.cyan);
        box.add(modelLabel);

        maxSpeedText = new JTextField();
        maxSpeedText.setBounds(310, 173, 169, 25);
        maxSpeedText.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                int key = e.getKeyCode();
                if (e.getKeyChar() >= '0' && e.getKeyChar() <= '9' || key == KeyEvent.VK_DELETE) {
                    maxSpeedText.setEditable(true);
                } else maxSpeedText.setEditable(false);
            }
        });
        box.add(maxSpeedText);
        box.setSize(150, 10);
        return box;
    }

    private Box countryFlagLabel() {
        Box box = Box.createHorizontalBox();
        countryFlagLabel = new JLabel("Country flag :");
        countryFlagLabel.setForeground(Color.WHITE);
        countryFlagLabel.setBackground(Color.cyan);
        box.add(countryFlagLabel);

        countryFlagText = new JTextField();
        box.add(countryFlagText);
        box.setSize(150, 10);
        return box;
    }

    private Box maxPassengersLabel() {
        Box box = Box.createHorizontalBox();
        maxOfPassengerLabel = new JLabel("Max passengers :");
        maxOfPassengerLabel.setForeground(Color.WHITE);
        maxOfPassengerLabel.setBackground(Color.cyan);
        box.add(maxOfPassengerLabel);

        maxOfPassengerText = new JTextField();
        maxOfPassengerText.setBounds(310, 173, 169, 25);
        maxOfPassengerText.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                int key = e.getKeyCode();
                if (e.getKeyChar() >= '0' && e.getKeyChar() <= '9') {
                    maxOfPassengerText.setEditable(true);
                } else maxOfPassengerText.setEditable(false);
            }
        });
        box.add(maxOfPassengerText);
        box.setSize(150, 10);
        return box;
    }

    private Box averageLifeSpanLabel() {
        Box box = Box.createHorizontalBox();
        averageLifeSpanLabel = new JLabel("Average lifeSpan :");
        averageLifeSpanLabel.setForeground(Color.WHITE);
        averageLifeSpanLabel.setBackground(Color.cyan);
        box.add(averageLifeSpanLabel);

        averageLifeSpanText = new JTextField();
        averageLifeSpanText.setBackground(new Color(255, 255, 255, 255));
        averageLifeSpanText.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                int key = e.getKeyCode();
                if (e.getKeyChar() >= '0' && e.getKeyChar() <= '9') {
                    averageLifeSpanText.setEditable(true);
                } else averageLifeSpanText.setEditable(false);
            }
        });
        box.add(averageLifeSpanText);
        box.setSize(150, 10);
        return box;
    }

    public Box avgConsumptionLabel() {
        Box box = Box.createHorizontalBox();
        avgConsumptionLabel = new JLabel("Average Consumption :");
        avgConsumptionLabel.setForeground(Color.WHITE);
        avgConsumptionLabel.setBackground(Color.cyan);
        box.add(avgConsumptionLabel);

        avgConsumptionText = new JTextField();
        avgConsumptionText.setBackground(new Color(255, 255, 255, 255));
        avgConsumptionText.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                int key = e.getKeyCode();
                if (e.getKeyChar() >= '0' && e.getKeyChar() <= '9') {
                    avgConsumptionText.setEditable(true);
                } else avgConsumptionText.setEditable(false);
            }
        });
        box.add(avgConsumptionText);
        box.setSize(150, 10);
        return box;
    }

    private Box windRadioButtons() {
        Box box = Box.createHorizontalBox();
        withTheWindButton = new JRadioButton("with the wind");
        againstTheWindButton = new JRadioButton("against the wind");

        withTheWindButton.setBackground(Color.white);
        withTheWindButton.setForeground(Color.blue);

        againstTheWindButton.setBackground(Color.white);
        againstTheWindButton.setForeground(Color.blue);

        box.add(againstTheWindButton);
        box.add(withTheWindButton);

        withTheWindButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                withTheWind = true;
            }
        });
        againstTheWindButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                againstTheWind = true;
            }
        });
        return box;
    }

    private Box civilianOrMilitaryRadioButtons() {
        Box box = Box.createHorizontalBox();
        civilianButton = new JRadioButton("civilian");
        militaryButton = new JRadioButton("military");

        civilianButton.setBackground(Color.white);
        civilianButton.setForeground(Color.blue);
        militaryButton.setForeground(Color.blue);



        box.add(civilianButton);
        box.add(militaryButton);
        civilianButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                civilian = true;
            }
        });
        militaryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                military = true;
            }
        });
        return box;
    }

    @Override
    public void actionPerformed(ActionEvent e) { // menu
        resetAllTextFields();
        if (e.getSource() == menuButton) {
            goToMenu();
        }
    }

    public void resetKm() {
        resetPanel();
        if (arr.size() == 0) {
            JOptionPane.showMessageDialog(frame, "No vehicles in stock");
        } else {
            for (Vehicles vehicles : arr) vehicles.setKm(0);
            JOptionPane.showMessageDialog(frame, "reset Km succeeded");
        }
        goToMenu();
    }

    public void changeAllFlags() {
        resetInnerPanel();
        resetPanel();
        goToMenuButton();
        changeAllFlagsBtn();
        innerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        innerPanel.setBackground(new Color(255, 255, 255, 65));
        innerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // add a 10-pixel border
        innerPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));

        innerPanel.add(getFlagForFile("/Users/yrdnqldrwn/Desktop/SOFTWARE/IntelliJ #Java/homeWork/p1/p1/src/Graphic/israel.png", Country.Israel));
        innerPanel.add(getFlagForFile("/Users/yrdnqldrwn/Desktop/SOFTWARE/IntelliJ #Java/homeWork/p1/p1/src/Graphic/Greece.png", Country.Greece));
        innerPanel.add(getFlagForFile("/Users/yrdnqldrwn/Desktop/SOFTWARE/IntelliJ #Java/homeWork/p1/p1/src/Graphic/UnitedStates.png", Country.UnitedStates));
        innerPanel.add(getFlagForFile("/Users/yrdnqldrwn/Desktop/SOFTWARE/IntelliJ #Java/homeWork/p1/p1/src/Graphic/Italy.png", Country.Italy));
        innerPanel.add(getFlagForFile("/Users/yrdnqldrwn/Desktop/SOFTWARE/IntelliJ #Java/homeWork/p1/p1/src/Graphic/Somalia.png", Country.Somalia));
        innerPanel.add(getFlagForFile("/Users/yrdnqldrwn/Desktop/SOFTWARE/IntelliJ #Java/homeWork/p1/p1/src/Graphic/ Germany.png", Country.Germany));
        innerPanel.add(getFlagForFile("/Users/yrdnqldrwn/Desktop/SOFTWARE/IntelliJ #Java/homeWork/p1/p1/src/Graphic/Pirates.png", Country.Pirates));


        innerPanel.setBounds(0, 0, width, height);
        panel.add(innerPanel);
    }

    private void changeAllFlagsBtn() {  // change all the flags
        final boolean[] flag = {false};
        resetFlagBtn = new JButton("Change flags");
        resetFlagBtn.setBounds(200, 200, 190, 50);
        resetFlagBtn.setBackground(new Color(255, 255, 255, 255));
        panel.add(resetFlagBtn);
        resetFlagBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get the currently selected radio button
                JRadioButton selectedButton = null;
                Enumeration<AbstractButton> buttons = buttonGroup.getElements();
                while (buttons.hasMoreElements()) {
                    JRadioButton button = (JRadioButton) buttons.nextElement();
                    if (button.isSelected()) {
                        selectedButton = button;
                        break;
                    }
                }
                // If a radio button is selected, set the flags for all water vehicles
                if (selectedButton != null) {
                    Country selectedCountry = Country.valueOf(selectedButton.getText());
                    for (int i = 0; i < arr.size(); i++) {
                        if ((arr.get(i) instanceof WaterVehicle)) {
                            ((WaterVehicle) arr.get(i)).setCountryFlag(selectedCountry.name());
                            flag[0] = true;
                        }
                    }
                    if (flag[0])
                        JOptionPane.showMessageDialog(null, "Flags have been successfully reset.");
                    else
                        JOptionPane.showMessageDialog(null, "No marine vehicles in stock.");

                    goToMenu();
                }
            }
        });
    }

    private void goToMenuButton() {
        menuButton = new JButton("Go to menu.");
        menuButton.setBounds(49, 450, 90, 50);
        menuButton.setBackground(new Color(255, 255, 255, 255));
        menuButton.addActionListener(this);
        panel.add(menuButton);
    }

    private void goToMenu() {  // menu
        resetPanel();
        resetInnerPanel();
        boxContainer = Box.createHorizontalBox();
        boxContainer.setSize(width / 7, height / 7);
        goToMenuButton();

        buyVehicles = new JButton("Buy vehicles");
        buyVehicles.setBounds(290, 70, 250, 50);
        panel.add(buyVehicles);
        buyVehicles.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                resetPanel();
                goToMenuButton();
                if (arr.size() == 0) {
                    JOptionPane.showMessageDialog(frame, "No vehicles in stock.");
                    goToMenu();
                } else {
                    resetInnerPanel();
                    resetPanel();
                    goToMenuButton();
                    buttonVehiclesGroup = new ButtonGroup();
                    innerPanel.setBounds(0, 0, width, height);
                    innerPanel.setBackground(new Color(255, 255, 255, 65));
                    innerPanel.add(buyButton());
                    innerPanel.add(printAllVehiclesPictures());
                    panel.add(innerPanel);
                }
            }
        });

        testDrive = new JButton("Test drive");
        testDrive.setBounds(290, 140, 250, 50);
        panel.add(testDrive);
        testDrive.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                resetPanel();
                if (arr.size() == 0) {
                    JOptionPane.showMessageDialog(frame, "No vehicles in stock.");
                    goToMenu();
                } else {
                resetInnerPanel();
                resetPanel();
                goToMenuButton();
                buttonVehiclesGroup = new ButtonGroup();
                innerPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 20));
                innerPanel.setBounds(0, 0, width, height);
                innerPanel.setBackground(new Color(255, 255, 255, 65));
                innerPanel.add(kmLabel());
                innerPanel.add(printAllVehiclesPictures());
                innerPanel.add(testDriveButton());
                panel.add(innerPanel);
                }
            }
        });

        resetkm = new JButton("Reset kilometer");
        resetkm.setBounds(290, 210, 250, 50);
        panel.add(resetkm);
        resetkm.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (arr.size() == 0) {
                    JOptionPane.showMessageDialog(frame, "No vehicles in stock.");
                } else resetKm();
            }
        });

        changeFlagsn = new JButton("Change flags");
        changeFlagsn.setBounds(290, 280, 250, 50);
        panel.add(changeFlagsn);
        changeFlagsn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (arr.size() == 0) {
                    JOptionPane.showMessageDialog(frame, "No vehicles in stock.");
                } else {
                    changeAllFlags();
                }
            }
        });

        addVehicle = new JButton("Add vehicle");
        addVehicle.setBounds(290, 350, 250, 50);
        panel.add(addVehicle);
        addVehicle.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                resetInnerPanel();
                innerPanel.setBackground(new Color(0, 0, 0, 224));
                innerPanel.setLayout(new BorderLayout());
                innerPanel.setSize(width / 2, height / 2);
                addvehicleBox();
            }
        });

        currentInventoryReportBtn = new JButton("Current inventory report");
        currentInventoryReportBtn.setBounds(290, 420, 250, 50);
        panel.add(currentInventoryReportBtn);
        currentInventoryReportBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                resetPanel();
                goToMenuButton();
                if (arr.size() == 0) {
                    JOptionPane.showMessageDialog(frame, "No vehicles in stock.");
                    goToMenu();
                } else {
                    resetInnerPanel();
                    resetPanel();
                    goToMenuButton();
                    buttonVehiclesGroup = new ButtonGroup();
                    innerPanel.setBounds(0, 0, width, height);
                    innerPanel.setBackground(new Color(255, 255, 255, 65));
                    innerPanel.add(printAllVehiclesPictures());
                    panel.add(innerPanel);
                    // Hide or disable the radio buttons in the button group
                    Enumeration<AbstractButton> buttons = buttonVehiclesGroup.getElements();
                    while (buttons.hasMoreElements()) {
                        AbstractButton button = buttons.nextElement();
                        button.setVisible(false); // or button.setEnabled(false) to disable
                    }

                }
            }
        });

    } // menu

    private Box printAllVehiclesPictures(){
        Box box = Box.createHorizontalBox();
        box.add(Box.createGlue());
        box.setBounds(0, 0, width, height);
        box.add(printAllLandVehiclesPictures());
        box.add(Box.createHorizontalStrut(50)); // Add a 50-pixel gap
        box.add(printAllWaterVehiclesPictures());
        box.add(Box.createHorizontalStrut(50)); // Add another 50-pixel gap
        box.add(printAllAirVehiclesPictures());
        return box;
    } // Arranges the pictures of the vehicles in columns

    private Box printAllLandVehiclesPictures() {
        boolean flag = false;
        Box box = Box.createVerticalBox();
        ImageIcon imageIcon;
        JLabel title = new JLabel("All the land vehicles :");
        title.setForeground(Color.black);
        box.add(title);

        for (int i = 0; i < arr.size(); ++i) {
            if (arr.get(i) instanceof LandVehicle || arr.get(i) instanceof iLandVehicle) {
                flag = true;
                imageIcon = arr.get(i).getVehiclesImage();
                JRadioButton radioButton = new JRadioButton(); // Create a radio button
                radioButton.setActionCommand(Integer.toString(i)); // Set action command to the index of the vehicle in the array
                buttonVehiclesGroup.add(radioButton); // Add the radio button to the ButtonGroup
                JLabel imageLabel = new JLabel(imageIcon);
                final String tooltipText = arr.get(i).toString(); // Store tooltip text in final variable
                imageLabel.setToolTipText(tooltipText);
                imageLabel.addMouseListener(new MouseAdapter() { // Add mouse listener
                    @Override
                    public void mouseEntered(MouseEvent e) {
                        imageLabel.setToolTipText(tooltipText); // Set tooltip text when mouse enters label
                    }
                });
                Box radioButtonBox = Box.createVerticalBox(); // Create a box for the radio button and the image label
                radioButtonBox.add(radioButton);
                radioButtonBox.add(imageLabel);
                box.add(Box.createVerticalStrut(12)); // Add a 12-pixel gap
                box.add(radioButtonBox);
            }
        }
        if (!flag) {
            JLabel label = new JLabel("No land Vehicles on stock");
            box.add(label);
        }
        return box;
    }

    private Box printAllAirVehiclesPictures() {
        boolean flag = false;
        Box box = Box.createVerticalBox();
        ImageIcon imageIcon;
        JLabel title = new JLabel("All the air vehicles :");
        title.setForeground(Color.black);
        box.add(title);


        for (int i = 0; i < arr.size(); ++i) {
            if (arr.get(i) instanceof AirVehicle || arr.get(i) instanceof iAirVehicle) {
                flag = true;
                imageIcon = arr.get(i).getVehiclesImage();
                JRadioButton radioButton = new JRadioButton(); // Create a radio button
                radioButton.setActionCommand(Integer.toString(i)); // Set action command to the index of the vehicle in the array
                buttonVehiclesGroup.add(radioButton); // Add the radio button to the ButtonGroup
                JLabel imageLabel = new JLabel(imageIcon);
                final String tooltipText = arr.get(i).toString(); // Store tooltip text in final variable
                imageLabel.setToolTipText(tooltipText);
                imageLabel.addMouseListener(new MouseAdapter() { // Add mouse listener
                    @Override
                    public void mouseEntered(MouseEvent e) {
                        imageLabel.setToolTipText(tooltipText); // Set tooltip text when mouse enters label
                    }
                });
                Box radioButtonBox = Box.createVerticalBox(); // Create a box for the radio button and the image label
                radioButtonBox.add(radioButton);
                radioButtonBox.add(imageLabel);
                box.add(Box.createVerticalStrut(12)); // Add a 12-pixel gap
                box.add(radioButtonBox);
            }
        }
        if (!flag) {
            JLabel label = new JLabel("No air vehicles on stock");
            box.add(label);
        }

        return box;
    }

    private Box printAllWaterVehiclesPictures() {
        boolean flag = false;
        Box box = Box.createVerticalBox();
        ImageIcon imageIcon;
        JLabel title = new JLabel("All the water vehicles :");
        title.setForeground(Color.black);
        box.add(title);

        for (int i = 0; i < arr.size(); ++i) {
            if (arr.get(i) instanceof WaterVehicle || arr.get(i) instanceof  iWaterVehicle) {
                flag = true;
                imageIcon = arr.get(i).getVehiclesImage();
                JRadioButton radioButton = new JRadioButton(); // Create a radio button
                radioButton.setActionCommand(Integer.toString(i)); // Set action command to the index of the vehicle in the array
                buttonVehiclesGroup.add(radioButton); // Add the radio button to the ButtonGroup
                JLabel imageLabel = new JLabel(imageIcon);
                final String tooltipText = arr.get(i).toString(); // Store tooltip text in final variable
                imageLabel.setToolTipText(tooltipText);
                imageLabel.addMouseListener(new MouseAdapter() { // Add mouse listener
                    @Override
                    public void mouseEntered(MouseEvent e) {
                        imageLabel.setToolTipText(tooltipText); // Set tooltip text when mouse enters label
                    }
                });
                Box radioButtonBox = Box.createVerticalBox(); // Create a box for the radio button and the image label
                radioButtonBox.add(radioButton);
                radioButtonBox.add(imageLabel);
                box.add(Box.createVerticalStrut(12)); // Add a 12-pixel gap
                box.add(radioButtonBox);
            }
        }
        if (!flag) {
            JLabel label = new JLabel("No water Vehicles on stock");
            box.add(label);
        }
        return box;
    }

    private JButton buyButton() {
        JButton buyButton = new JButton("Buy Vehicle"); // Create the Buy Vehicle button
        buyButton.setBounds(670, 500, 105, 65);
        buyButton.setBackground(Color.white);
        buyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ButtonModel selectedButton = buttonVehiclesGroup.getSelection();
                if (selectedButton != null) {
                    String actionCommand = buttonVehiclesGroup.getSelection().getActionCommand(); // Get the action command of the selected radio button
                    int index = Integer.parseInt(actionCommand); // Convert the action command to an integer index
                    arr.remove(index); // Remove the vehicle from the array
                    JOptionPane.showMessageDialog(null, "Vehicle bought successfully"); // Show a message to the user
                    goToMenu();
                } else JOptionPane.showMessageDialog(null, "Please select a vehicle");
            }
        });
        return buyButton;
    }

    private JButton testDriveButton() {
        JButton buyButton = new JButton("Add kilometer"); // Create the Buy Vehicle button
        buyButton.setBounds(500, 900, 85, 100);
        buyButton.setBackground(Color.white);
        buyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ButtonModel selectedButton = buttonVehiclesGroup.getSelection();
                if (selectedButton != null) {
                    String actionCommand = buttonVehiclesGroup.getSelection().getActionCommand(); // Get the action command of the selected radio button
                    if (!kmText.getText().trim().isEmpty()) {
                        int index = Integer.parseInt(actionCommand); // Convert the action command to an integer index
                        arr.get(index).addToKm(Integer.parseInt(kmText.getText()));
                        JOptionPane.showMessageDialog(null, "The kilometer has been successfully added"); // Show a message to the user
                    } else JOptionPane.showMessageDialog(null, "please enter kilometer to add");
                } else JOptionPane.showMessageDialog(null, "Please select a vehicle");
            }
        });
        return buyButton;
    }

    private Box getFlagForFile(String filePath, Country country) {
        Box box = Box.createVerticalBox();
        try {
            BufferedImage bufferedImage = ImageIO.read(new File(filePath));
            bufferedImage = resizePic(bufferedImage, 100, 70);
            ImageIcon icon = new ImageIcon(bufferedImage);
            JLabel label = new JLabel(icon);
            box.add(label);
            radioFlagBtn = new JRadioButton(country.name());
            buttonGroup.add(radioFlagBtn); // Add the radio button to the ButtonGroup
            radioFlagBtn.setBorder(BorderFactory.createEmptyBorder(0, 42, 0, 0));  // Add an EmptyBorder with 5 pixels of padding on the right side
            box.add(radioFlagBtn);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return box;
    }

    public static BufferedImage resizePic(BufferedImage img, int newW, int newH) {  // Resize the image as needed
        Image tmp = img.getScaledInstance(newW, newH, Image.SCALE_SMOOTH);
        BufferedImage dimg = new BufferedImage(newW, newH, BufferedImage.TYPE_INT_ARGB);

        Graphics2D g2d = dimg.createGraphics();
        g2d.drawImage(tmp, 0, 0, null);
        g2d.dispose();

        return dimg;
    } // resize the size of image

    private Box addVehicleBtn(VehicleType vehicleType) {

        Box box = Box.createHorizontalBox();
        addVehicleBtn = new JButton("Add Vehicle.");
        addVehicleBtn.setBackground(Color.white);
        addVehicleBtn.setSize(100, 100);
        addVehicleBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                switch (vehicleType) {
                    case Frigate -> {
                        boolean inputNotEmpty = !modelText.getText().trim().isEmpty() && !maxKmText.getText().trim().isEmpty() && !maxOfPassengerText.getText().trim().isEmpty()
                                && !maxSpeedText.getText().trim().isEmpty() && (withTheWindButton.isSelected() || againstTheWindButton.isSelected());

                        if (!inputNotEmpty || !imageSelcted)
                            JOptionPane.showMessageDialog(frame, "Pleas fill all the empty fields !!");

                        else {
                            Frigate frigate = new Frigate(modelText.getText(), 0, Integer.parseInt(maxKmText.getText()), Integer.parseInt(maxOfPassengerText.getText()), Integer.parseInt(maxSpeedText.getText()), withTheWind);
                            frigate.setVehiclesImage(vehiclesImage);
                            arr.add(frigate);
                            JOptionPane.showMessageDialog(frame, "You have successfully added the Frigate");
                            resetAllTextFields();
                            addvehicleBox();
                            imageSelcted = false;
                        }
                    }
                    case CruiseShip -> {
                        boolean inputNotEmpty = !modelText.getText().trim().isEmpty() && !maxKmText.getText().trim().isEmpty() && !maxOfPassengerText.getText().trim().isEmpty()
                                && !maxSpeedText.getText().trim().isEmpty();

                        if (!inputNotEmpty || !imageSelcted)  JOptionPane.showMessageDialog(frame, "Pleas fill all the empty fields !!");
                        else {
                            CruiseShip cruiseShip = new CruiseShip(modelText.getText(), 0, Integer.parseInt(maxKmText.getText()), Integer.parseInt(maxOfPassengerText.getText()), Integer.parseInt(maxSpeedText.getText()), "israel", Integer.parseInt(averageLifeSpanText.getText()));
                            cruiseShip.setVehiclesImage(vehiclesImage);
                            arr.add(cruiseShip);
                            JOptionPane.showMessageDialog(frame, "You have successfully added the CruiseShip");
                            resetAllTextFields();
                            addvehicleBox();
                            imageSelcted = false;
                        }
                    }
                    case Bicycle -> {
                        boolean inputNotEmpty = !modelText.getText().trim().isEmpty() && !submodelText.getText().trim().isEmpty();

                        if (!inputNotEmpty || !imageSelcted)
                            JOptionPane.showMessageDialog(frame, "Pleas fill all the empty fields !!");
                        else {
                            Bicycle bicycle = new Bicycle(modelText.getText(), modelText.getText());
                            bicycle.setVehiclesImage(vehiclesImage);
                            arr.add(bicycle);
                            String str = bicycle.toString();
                            System.out.println(str);
                            JOptionPane.showMessageDialog(frame, "You have successfully added the bicycle");
                            resetAllTextFields();
                            addvehicleBox();
                            imageSelcted = false;
                        }
                    }
                    case PlayGlider -> {
                        boolean inputNotEmpty = !maxKmText.getText().trim().isEmpty() && !averageLifeSpanText.getText().trim().isEmpty();

                        if (!inputNotEmpty || !imageSelcted)
                            JOptionPane.showMessageDialog(frame, "Pleas fill all the empty fields !!");

                        else {
                            PlayGlider playGlider = new PlayGlider(0, Integer.parseInt(maxKmText.getText()), Integer.parseInt(averageLifeSpanText.getText()));
                            playGlider.setVehiclesImage(vehiclesImage);
                            arr.add(playGlider);
                            JOptionPane.showMessageDialog(frame, "You have successfully added the Play Glider");
                            resetAllTextFields();
                            addvehicleBox();
                            imageSelcted = false;
                        }
                    }
                    case SpyGlider -> {
                        boolean inputNotEmpty = !maxKmText.getText().trim().isEmpty() && !averageLifeSpanText.getText().trim().isEmpty();

                        if (!inputNotEmpty || !imageSelcted)
                            JOptionPane.showMessageDialog(frame, "Pleas fill all the empty fields !!");

                        else {
                            SpyGlider spyGlider = new SpyGlider(0, Integer.parseInt(maxKmText.getText()), Integer.parseInt(averageLifeSpanText.getText()));
                            spyGlider.setVehiclesImage(vehiclesImage);
                            arr.add(spyGlider);
                            JOptionPane.showMessageDialog(frame, "You have successfully added the Spy Glider");
                            resetAllTextFields();
                            addvehicleBox();
                            imageSelcted = false;
                        }
                    }
                    case Amphibious -> {
                        boolean inputNotEmpty = !modelText.getText().trim().isEmpty() && !submodelText.getText().trim().isEmpty() && !maxKmText.getText().trim().isEmpty() && !maxOfPassengerText.getText().trim().isEmpty()
                                && !maxSpeedText.getText().trim().isEmpty() && !numOfWheelsText.getText().trim().isEmpty();

                        if (!inputNotEmpty || !imageSelcted)  JOptionPane.showMessageDialog(frame, "Pleas fill all the empty fields !!");
                        else {
                            Amphibious amphibious = new Amphibious(modelText.getText(), submodelText.getText(), 0, Integer.parseInt(maxKmText.getText()), Integer.parseInt(maxOfPassengerText.getText()), Integer.parseInt(maxSpeedText.getText()),
                                    withTheWind, "israel", Integer.parseInt(numOfWheelsText.getText()));
                            amphibious.setVehiclesImage(vehiclesImage);
                            arr.add(amphibious);
                            JOptionPane.showMessageDialog(frame, "You have successfully added the amphibious");
                            resetAllTextFields();
                            addvehicleBox();
                            imageSelcted = false;
                        }
                    }
                    case Jeep -> {
                        boolean inputNotEmpty = !modelText.getText().trim().isEmpty() && !submodelText.getText().trim().isEmpty() && !maxKmText.getText().trim().isEmpty()
                                && !maxOfPassengerText.getText().trim().isEmpty() && !maxSpeedText.getText().trim().isEmpty() && !avgConsumptionText.getText().trim().isEmpty() && !averageLifeSpanText.getText().trim().isEmpty();

                        if (!inputNotEmpty || !imageSelcted)
                            JOptionPane.showMessageDialog(frame, "Please fill all the empty fields !!");

                        else {
                            Jeep jeep = new Jeep(modelText.getText(), submodelText.getText(), 0, Integer.parseInt(maxKmText.getText()), Integer.parseInt(maxOfPassengerText.getText()), Integer.parseInt(maxSpeedText.getText()),
                                    Integer.parseInt(avgConsumptionText.getText()), Integer.parseInt(averageLifeSpanText.getText()));
                            String str = jeep.toString();
                            System.out.println(str);
                            jeep.setVehiclesImage(vehiclesImage);
                            arr.add(jeep);
                            JOptionPane.showMessageDialog(frame, "You have successfully added the Jeep");
                            resetAllTextFields();
                            addvehicleBox();
                            imageSelcted = false;
                        }
                    }
                    case HybridPlane-> {
                        boolean inputNotEmpty = !modelText.getText().trim().isEmpty() && !submodelText.getText().trim().isEmpty() && !maxKmText.getText().trim().isEmpty()
                                && !maxOfPassengerText.getText().trim().isEmpty() && !maxSpeedText.getText().trim().isEmpty() && !avgConsumptionText.getText().trim().isEmpty() && !averageLifeSpanText.getText().trim().isEmpty() &&
                                !numOfWheelsText.getText().trim().isEmpty() && (withTheWindButton.isSelected() || againstTheWindButton.isSelected()) && (civilianButton.isSelected() || militaryButton.isSelected());
                        if (!inputNotEmpty || !imageSelcted)
                            JOptionPane.showMessageDialog(frame, "Pleas fill all the empty fields !!");
                        else {
                            HybridPlane hybridPlane = new HybridPlane(modelText.getText(), submodelText.getText(), 0, Integer.parseInt(maxKmText.getText()), Integer.parseInt(maxOfPassengerText.getText()), Integer.parseInt(maxSpeedText.getText()), civilian, military,
                                    Integer.parseInt(averageLifeSpanText.getText()), Integer.parseInt(numOfWheelsText.getText()), withTheWind, "israel");
                            hybridPlane.setVehiclesImage(vehiclesImage);
                            arr.add(hybridPlane);
                            JOptionPane.showMessageDialog(frame, "You have successfully added the hybrid Plane");
                            resetAllTextFields();
                            addvehicleBox();
                            imageSelcted = false;
                        }

                    }
                    case ElectricBicycle -> {
                        boolean inputNotEmpty = !modelText.getText().trim().isEmpty() && !submodelText.getText().trim().isEmpty();

                        if (!inputNotEmpty || !imageSelcted)
                            JOptionPane.showMessageDialog(frame, "Pleas fill all the empty fields !!");
                        else {
                            ElectricBicycle eBicycle = new ElectricBicycle(modelText.getText(), modelText.getText());
                            eBicycle.setVehiclesImage(vehiclesImage);
                            arr.add(eBicycle);
                            JOptionPane.showMessageDialog(frame, "You have successfully added the electric bicycle");
                            resetAllTextFields();
                            addvehicleBox();
                            imageSelcted = false;
                        }
                    }
                }
            }
        });
        box.add(addVehicleBtn);
        return box;
    } // to add Vehicle to array

    private boolean isContains(Vehicles vehicles) {
        return indexOf(vehicles) != -1;
    }

    private int indexOf(Vehicles vehicles) {
        int ans = -1;
        for (int i = 0; i < arr.size(); i++) {
            if (this.arr.get(i).equals(vehicles)) {
                ans = i;
                break;
            }
        }
        return ans;
    }

}

