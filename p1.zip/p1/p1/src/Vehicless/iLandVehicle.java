package Vehicless;

import javax.swing.*;

public interface iLandVehicle {

    String toString();
    boolean equals(Object anObj);
    String roadType();
//    void setVehiclesImage(ImageIcon vehiclesImage);
//    ImageIcon getVehiclesImage();
}
