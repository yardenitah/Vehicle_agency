package Vehicless;

public interface iAirVehicle {

    String toString();
    boolean equals(Object anObj);
    String militaryOrCivilian(boolean military, boolean civilian);
}
