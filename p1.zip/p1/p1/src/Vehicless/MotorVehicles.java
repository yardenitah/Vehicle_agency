package Vehicless;

public interface MotorVehicles {
    void AverageConsumption(int km, int amountoFgas);
}
