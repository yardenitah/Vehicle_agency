package Vehicless;

public class ElectricBicycle extends Bicycle implements iLandVehicle, MotorVehicles{
    public ElectricBicycle(String model, String subModel) {
        super(model, subModel);
        this.AverageConsumption = 20;
    }
    private  float AverageConsumption;

    @Override
    public String toString() {
        String str = ("Electric Bicycle:\n model: "+this.model+"\n sub model: "+this.subModel+"\n energy score: "+this.energyScore()+"\n road type:" +this.roadType());
        return str;
    }

    @Override
    public void AverageConsumption(int km, int amountoFgas) {
        return;
    }
}
