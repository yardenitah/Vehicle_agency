//package Vehicless;
//
//public interface ImVehicle {
//    void handleVehicleSelection(Object obj);
//}
