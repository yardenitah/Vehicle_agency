package Vehicless;

public class Amphibious extends WaterVehicle implements iLandVehicle, iWaterVehicle,MotorVehicles {

    private final iLandVehicle landVehicle;
    public Amphibious(String model, String subModel, int kilometers, int maxKilometers, int maxOfPassengers, int maxSpeed, boolean withTheWind, String countryFlag, int numOfWheels) {
        super(model, kilometers, maxKilometers, maxOfPassengers, maxSpeed, withTheWind, countryFlag);
        landVehicle = new LandVehicle(model, subModel, kilometers, maxKilometers, maxOfPassengers, maxSpeed, false, true, numOfWheels);
    }


    @Override
    public boolean equals(Object anObj) {
        if (anObj instanceof Amphibious) {
           return super.equals(anObj) && this.landVehicle.equals(anObj);
        }
        return false;
    }

    @Override
    public String toString() {
       String str1 = "Amphibious: ";
        return str1+"\n"+super.toString()+"\n"+landVehicle.toString();
    }

    @Override
    public void AverageConsumption(int km, int amountoFgas) {
        if (km != 0)
        this.AverageConsumption = amountoFgas / km;
    }

    @Override
    public String roadType() {
       return landVehicle.roadType();
    }
}
//
//
//    private final iWaterVehicle waterVehicle;
//    private final iLandVehicle landVehicle;
//    public Amphibious(String model, String subModel, int kilometers, int maxKilometers, int maxOfPassengers, int maxSpeed, boolean withTheWind, String countryFlag, int numOfWheels) {
//        waterVehicle = new WaterVehicle(model, kilometers, maxKilometers, maxOfPassengers, maxSpeed, true, countryFlag) {
//            @Override
//            public boolean equals(Object anObj) {
//                if (anObj instanceof Frigate){
//                    Frigate frigate = (Frigate) anObj;
//                    return this.kilometers == frigate.kilometers && this.maxKilometers == frigate.maxKilometers && this.maxSpeed == frigate.maxSpeed && this.AverageConsumption == frigate.AverageConsumption && this.countryFlag.equals(frigate.countryFlag);
//                }
//                return false;
//            }
//            @Override
//            public String toString() {
//                String str2;
//                String str = ("Frigate:\n Model:"+this.model+"\n traveled:"+this.kilometers+"\n Average Consumption: "+"\n Max speed:"+this.maxSpeed+" Mph"+"\n can carry max of people:"+this.maxOfPassengers+"\n Country Flag: "+this.countryFlag+"\n engine: "+this.AverageConsumption+"L");
//                if (this.withTheWind)  str2 = "with the wind";
//                else  str2 = "against the wind";
//                String res = str + "\n " + str2;
//                return res;
//            }
//        };
//        landVehicle = new LandVehicle(model, subModel, kilometers, maxKilometers, maxOfPassengers, maxSpeed, false, true, numOfWheels) {
//            @Override
//            public boolean equals(Object anObj) {
//                if (anObj instanceof Jeep) {
//                    Jeep jeep = (Jeep) anObj;
//                    return jeep.model.equals(this.model) && jeep.subModel.equals(this.subModel) && jeep.kilometers == this.kilometers && jeep.maxKilometers == this.maxKilometers && jeep.maxOfPassengers == this.maxOfPassengers && jeep.maxSpeed == this.maxSpeed;
//                }
//                return false;
//            }
//            @Override
//            public String toString() {
//                String str = ("JEEP:\n Model:"+this.model+"\n Sub Model:"+this.subModel+"\n traveled:"+this.kilometers+" km "+"\n max kilometer:" +this.maxKilometers+"\n average life span: \n Max speed:"+this.maxSpeed+" Mph"+"\n can carry max of people:"+this.maxOfPassengers+"\n road type: "+this.roadType());
//                return str;
//            }
//        };
//    }
//    @Override
//    public String toString() { return waterVehicle.toString() + "\n" + landVehicle.toString(); }
//    @Override
//    public String roadType() { return landVehicle.roadType();}
//    @Override
//    public void setCountryFlag(String countryFlag) { waterVehicle.setCountryFlag(countryFlag); }
//
//    @Override
//    public boolean equals(Object anObj){ return waterVehicle.equals(anObj) && landVehicle.equals(anObj); }
//    @Override
//    public void AverageConsumption(int km, int amountoFgas) { this.AverageConsumption(km, amountoFgas); }