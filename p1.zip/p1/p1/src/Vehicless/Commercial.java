package Vehicless;

public interface Commercial {
    void licenseType();
}
