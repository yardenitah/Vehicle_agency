package Vehicless;

public interface NonMotorizedVehicles {
    char energyScore();
}
