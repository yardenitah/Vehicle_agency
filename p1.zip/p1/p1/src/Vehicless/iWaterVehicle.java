package Vehicless;

import javax.swing.*;

public interface iWaterVehicle {
    String toString();
    boolean equals(Object anObj);
    void setCountryFlag(String countryFlag);

//    void setVehiclesImage(ImageIcon vehiclesImage);
//    ImageIcon getVehiclesImage();
}
